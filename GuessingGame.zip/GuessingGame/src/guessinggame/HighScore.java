/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guessinggame;

/**
 *
 * @author Majeed
 */
public class HighScore extends GuessingGame {
    public void HighScore() {
        /*  
            High score
            ----------
            Guess the Number Best Score: Have not played yet
            Guess the Alphabet Best Score: 3 chances used up
        */
        
        GuessingNumber gN = new GuessingNumber();
        GuessingAlphabet gA = new GuessingAlphabet();
        
        System.out.println("High score");
        System.out.println("----------");
        System.out.println("Guess the Number Best Score: " + gN.getScore());
        System.out.println("Guess the Alphabet Best Score: " + gA.getScore());
    }
}
