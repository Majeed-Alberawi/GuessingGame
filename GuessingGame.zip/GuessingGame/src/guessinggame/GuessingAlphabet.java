
package guessinggame;

import java.util.Scanner;


public class GuessingAlphabet {
    
    public int alphScore;
    
    public void GuessingAlphabet() {
        
        String[] arr = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        
        int ranNum = (int) (Math.random()*26);
        
        String trueAnsware = arr[ranNum];
        
        System.out.println(trueAnsware);
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("1. Easy");
        System.out.println("2. Medium");
        System.out.println("3. Hard");
        System.out.println("4. Return to main menu");

        System.out.print("===> ");
        
        int choice2 = input.nextInt();
        
        System.out.println("""
                               Instructions:
                                1. Guess the vowel alphabet.
                                2. You are allowed to make one guess at a time.
                                3. Each game has 2 chances to guess the correct vowel.
                                4. Once you have used up all your chances, you lose the game.""");
        System.out.println("Good Luck!");

        int k;
        int j;

        int chances;

        switch (choice2) {
            case 1 -> {
                chances = 2;
                k = 2;
                break;
            }
            case 2 -> {
                chances = 4;
                k = 4;
                break;
            }
            case 3 -> {
                chances = 5;
                k = 5;
                break;
            }
            default -> {
                chances = 2;
                k = 2;
                break;
            }
        }
        
        switch (choice2) {
            case 1 -> System.out.println("Easy: ");
            case 2 -> System.out.println("Medium: ");
            case 3 -> System.out.println("Hard: ");
            default -> System.out.println("Easy: ");
        }
        
        for (int i = 1; i <= k; i++) {
            
            System.out.println("Enter an alphabet: " + chances +" chances left. What is the alphabet?");
                
            chances -= 1;

            String answare = input.next();

            if (answare.equals(trueAnsware)) {
                System.out.println("Correct! You\'ve won the game with just " + i + " times.");
                alphScore = i;
                break;
            } else if (chances != 0 && !answare.equals(trueAnsware)) {
                System.out.println("Wrong! ");
            } else if (chances == 0) {
                System.out.println("You lost the game");
            }
            
        }
        
    }
    
    public int getScore() {
        
        if (alphScore == 0) {
            System.out.println("Have not played yet");
        }
        return alphScore;
    }

    
}
