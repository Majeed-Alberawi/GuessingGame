
package guessinggame;

import java.util.Scanner;

public class GuessingGame {

    public static void main(String[] args) {
        
//        GuessingAlphabet gA = new GuessingAlphabet();
        
        System.out.println("| MENU |");
        System.out.println("1. Guess The Number");
        System.out.println("2. Guess The Alphabet");
        System.out.println("3. Hight Score");
        System.out.println("4. Credit");
        System.out.println("5. Exit");
        
        System.out.print("Enter Your Choice: ");
        
        Scanner input = new Scanner(System.in);
        
        int choice = input.nextInt();
        
        if ( choice == 1) {
            
            GuessingNumber gN= new GuessingNumber();
            
            gN.guessingNumber();
        } else if ( choice  == 2 ) {
            
            GuessingAlphabet gA= new GuessingAlphabet();
            
            gA.GuessingAlphabet();
            
        } else if ( choice  == 3 ) {
            HighScore hS= new HighScore();
            
            hS.HighScore();
        }
        
        
    }
    
}
