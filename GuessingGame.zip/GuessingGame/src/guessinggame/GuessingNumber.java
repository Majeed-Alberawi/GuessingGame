
package guessinggame;

import java.util.Scanner;

public class GuessingNumber {
    
    private int numScore;
    
    public void guessingNumber() {
        System.out.println("1. Easy");
        System.out.println("2. Medium");
        System.out.println("3. Hard");
        System.out.println("4. Return to main menu");

        System.out.print("===> ");

        Scanner input = new Scanner(System.in);

        int choice2 = input.nextInt();

        System.out.println("""
                               Instructions:
                                1. Guess the number based on the gaven range.
                                2. You are allowed to make one guess at a time.
                                3. Each game has 5 chances to guess the correct number.
                                4. Once you have used up all your chances, you lose the game.""");
        System.out.println("Good Luck!");

        int k;
        int j;

        int chances;

        switch (choice2) {
            case 1 -> {
                chances = 5;
                k = 5;
                j = 15;
                break;
            }
            case 2 -> {
                chances = 4;
                k = 4;
                j = 20;
                break;
            }
            case 3 -> {
                chances = 3;
                k = 3;
                j = 40;
                break;
            }
            default -> {
                chances = 5;
                k = 5;
                j = 40;
                break;
            }
        }

        int trueAnsware = (int) (Math.random() * j);

        System.out.println(trueAnsware);

        switch (choice2) {
            case 1 -> System.out.println("Easy: ");
            case 2 -> System.out.println("Medium: ");
            case 3 -> System.out.println("Hard: ");
            default -> System.out.println("Easy: ");
        }
        
        for (int i = 1; i <= k; i++) {
            if (choice2 == 1) {
                System.out.println("Enter guess number from 1 to 15 . " + chances + " chances left.");
            } else if (choice2 == 2) {
                System.out.println("Enter guess number from 1 to 20 . " + chances + " chances left.");
            } else if (choice2 == 3) {
                System.out.println("Enter guess number from 1 to 40 . " + chances + " chances left.");
               
            }
            chances -= 1;
            int answare = input.nextInt();

            if (answare == trueAnsware) {
                System.out.println("Correct! You've won the game with just " + i + " times.");
                numScore = i;
                break;
            } else if (chances != 0 && answare != trueAnsware) {
                System.out.print("Wrong! ");
                if ((trueAnsware - answare) > 3) {
                    System.out.println("Wrong! Your guess was too low");
                } else if ((trueAnsware + answare) < trueAnsware + 3) {
                    System.out.println("Wrong! Your guess was too high");
                }
            } else if (chances == 0) {
                System.out.println("You lost the game");
            }
        }
    }
    
    public int getScore() {
        if (numScore == 0) {
            System.out.println("Have not played yet");
        }
        return numScore;
    }
    
}
